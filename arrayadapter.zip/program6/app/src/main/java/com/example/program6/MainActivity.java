package com.example.program6;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ListView listView;
    ArrayList<String> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);

        // Dataset (only one list like your first image)
        arrayList = new ArrayList<>();
        arrayList.add("Apple");
        arrayList.add("Mango");
        arrayList.add("Guava");
        arrayList.add("Banana");
        arrayList.add("Pineapple");
        arrayList.add("Kiwi");
        arrayList.add("Apple");
        arrayList.add("Mango");
        arrayList.add("Guava");
        arrayList.add("Banana");
        arrayList.add("Pineapple");
        arrayList.add("Kiwi");
        arrayList.add("Apple");
        arrayList.add("Mango");
        arrayList.add("Guava");
        arrayList.add("Banana");
        arrayList.add("Pineapple");
        arrayList.add("Kiwi");

        MyAdapter adapter = new MyAdapter();
        listView.setAdapter(adapter);
    }

    class MyAdapter extends ArrayAdapter<String> {

        MyAdapter() {
            super(MainActivity.this, R.layout.custom, arrayList);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View row = inflater.inflate(R.layout.custom, parent, false);

            ImageView img = row.findViewById(R.id.c_i_profile);
            TextView title = row.findViewById(R.id.c_t_data);
            TextView bottom = row.findViewById(R.id.c_t_bottom);

            img.setImageResource(R.drawable.ic_launcher_background);
            title.setText(arrayList.get(position));
            bottom.setText("bottomdata"); // FIXED text like first image

            return row;
        }
    }
}
