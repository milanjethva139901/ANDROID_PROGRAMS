package com.example.program3;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult;
    private double firstNumber = 0;
    private String operator = "";
    private boolean isNewInput = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
    }

    public void onDigit(View view) {
        Button button = (Button) view;

        if (isNewInput) {
            tvResult.setText(button.getText());
            isNewInput = false;
        } else {
            tvResult.append(button.getText());
        }
    }

    public void onOperator(View view) {
        Button button = (Button) view;

        firstNumber = Double.parseDouble(tvResult.getText().toString());
        operator = button.getText().toString();
        isNewInput = true;
    }

    public void onEqual(View view) {
        double secondNumber = Double.parseDouble(tvResult.getText().toString());
        double result;

        switch (operator) {
            case "+":
                result = firstNumber + secondNumber;
                break;
            case "-":
                result = firstNumber - secondNumber;
                break;
            case "*":
                result = firstNumber * secondNumber;
                break;
            case "/":
                result = firstNumber / secondNumber;
                break;
            default:
                result = 0;
        }

        tvResult.setText(String.valueOf(result));
        isNewInput = true;
    }

    public void onClear(View view) {
        tvResult.setText("0");
        firstNumber = 0;
        operator = "";
        isNewInput = true;
    }
}
