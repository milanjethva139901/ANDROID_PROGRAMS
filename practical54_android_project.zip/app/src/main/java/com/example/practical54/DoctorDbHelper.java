
package com.example.practical54;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DoctorDbHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "doctor.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE = "doctor";
    public static final String COL_ID = "doc_id";
    public static final String COL_FIRST = "firstname";
    public static final String COL_LAST = "lastname";
    public static final String COL_MOB = "mobile";
    public static final String COL_ADD = "address";
    public static final String COL_CITY = "city";
    public static final String COL_SPEC = "specialization";

    public DoctorDbHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String sql = "CREATE TABLE " + TABLE + " (" +
                COL_ID + " TEXT PRIMARY KEY," +
                COL_FIRST + " TEXT," +
                COL_LAST + " TEXT," +
                COL_MOB + " TEXT," +
                COL_ADD + " TEXT," +
                COL_CITY + " TEXT," +
                COL_SPEC + " TEXT)";
        db.execSQL(sql);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    public long insertDoctor(String id,String f,String l,String m,String a,String c,String s){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues v = new ContentValues();
        v.put(COL_ID,id);
        v.put(COL_FIRST,f);
        v.put(COL_LAST,l);
        v.put(COL_MOB,m);
        v.put(COL_ADD,a);
        v.put(COL_CITY,c);
        v.put(COL_SPEC,s);
        return db.insert(TABLE,null,v);
    }

    public Cursor findById(String id){
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE,null,COL_ID+"=?",new String[]{id},null,null,null);
    }
}
