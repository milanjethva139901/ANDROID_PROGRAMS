package com.example.program7;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView tv;
    CheckBox cb;
    Button btn;
    Switch sw;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.tv);
        cb = findViewById(R.id.cb);
        btn = findViewById(R.id.btn);
        sw = findViewById(R.id.sw);

        // CheckBox Listener
        cb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (cb.isChecked()) {
                    tv.setTextSize(30);
                } else {
                    tv.setTextSize(20);
                }
            }
        });

        // Button Listener
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tv.setTextSize(tv.getTextSize() / getResources().getDisplayMetrics().scaledDensity + 5);
            }
        });

        // Switch Listener
        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    tv.setTextSize(35);
                } else {
                    tv.setTextSize(20);
                }
            }
        });
    }
}
