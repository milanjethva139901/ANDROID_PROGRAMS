package com.example.program72;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.RadioGroup;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    ImageView img;
    RadioGroup rg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = findViewById(R.id.img);
        rg = findViewById(R.id.rg);

        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {

                if (checkedId == R.id.rb1) {
                    img.setImageResource(R.drawable.india);
                }
                else if (checkedId == R.id.rb2) {
                    img.setImageResource(R.drawable.australia);
                }
                else if (checkedId == R.id.rb3) {
                    img.setImageResource(R.drawable.fiji);
                }
            }
        });
    }
}
